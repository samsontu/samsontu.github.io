package Views_Package;

import Guideline_Model_Entity;
/**
 * <B>Description:</B><BR>
 *                  <BR>
 *                     
 *                   Note that any user should be able to see any entity in arbitrary detail, but only the specified user will see this level of detail by default
 *      .
 *                  <BR><BR>
 *                     
 *                     
 *                      <B>Purpose:</B><BR>
 *                  <BR>
 *                   
 *                  Views are a way of managing the complexity of guidelines.<BR>
 *                  <BR>
 *                  If we accept the thesis that one purpose of guidelines is to reduce practice variability in favor of superior patterns, it seems likely that guidelines with greater scope will eventually appear.<BR>
 *                  <BR>
 *   <img SRC="file:///C|/Together3.1/myprojects/Latest/Views_Package/Views_Pattern_of_Nesting4.gif" height=698 width=750>
 *   <BR><BR>
 *                  The status quo of specialty bodies publishing guidelines may change as multi-specialty organizations publish multi-specialty documents. Guidelines may become quite complex. <BR>
 *                  <BR>
 *                  Much of medicine is multi-disciplinary in nature. The distinction between specialties is artificial. For example, the distinction between cardiology and nursing is for the convenience of practitioners. The patient suffering a myocardial infarction (heart attack) is likely to require care from both a cardiologist and a nurse. The information needs of the cardiologist, however, are very different from those of the nurse. The purpose of default  views in GLIF should be to reveal to the cardiologist only the relevant portions of the myocardial infarction guideline, which may be different from that shown to the nurse. <BR><BR>
 *                   
 *                      <B>Consideration:</B><BR><BR>
 *                  
 *      
 *           Views are default filters through which we interact with the guideline. By definition, views do not change guideline logic (e.g. if an RN should do something different from an MD, this should be represented in the guideline logic, not in the view). Although we anticipate that the most common use of views will be user and/or location, there may be other relevant filters (e.g. situation such as routine vs. disaster).
 *      
 *            The view class is a guideline entity. Alternatively, the view could have been modeled as an enumerated type attribute. The main purpose of this class is to allow differential display in the simplest possible way.
 *                  <BR><BR>
 *          
 *         The view specification was chosen to be at the level of guideline entities and not at the attribute level. We may later choose to make <B>attributes</B> (and not entire guideline entities) visible or invisible to some users.<BR><BR>
 *       
 *                 Issues yet to be resolved:<BR><BR>
 *                 
 *                 1. Semantics of no default_user specified (e.g. confidential vs. visible to developer only). <BR><BR>
 *                2. Issues related to nesting?<BR><BR>
 *      <BR>
 */
public class View_Specification extends Guideline_Model_Entity {

/**
 * Data type: Filter_expression<BR>
 *    Multiplicity: 0:1<BR>
 *    Description: 
 *    Views are a filter applied to the guideline, there may be multiple relevant filters, e.g. viewer (MD vs. RN), location (office vs. hospital), situation (disaster vs. routine), etc.
 *       <BR><BR)
 *        
 *        View_Specification is an expression of these filters (e.g. MD in office, no disaster).<BR><BR>
 *       
 *       BNF:<BR><BR>
 *      
 *     <I> term: filter_type</I> <B>=</B> <I>domain_ontology_filter_instance</I><BR><BR>
 *      
 *      <I>filter_expression: term</I> | <I>expression binary_operator expression</I> | <I>unary_operator expression</I> | <B>(</B><I>expression</I><B>)</B><BR><BR>
 *      
 *      <I>binary_operator: </I><B>OR</B> | <B>AND</B><BR>
 *      <I>unary_operator</I>: <B>NOT</B><BR><BR>
 *     
 *     <I>filter_type</I>: <B>USER</B> | <B>LOCATION</B><BR><BR>
 *     <I>domain_ontology_filter_instance</I>: <B>MD</B> | <B>RN</B> | ...<BR><BR>
 *    
 *    Level: A, B and C
 */
    private Filter_expression filter;
}


